# Notebook cell 0 — copy the bundled `fonts/` directory too

The current cell 0 explicitly lists items to copy from Drive into Colab's
`/content/`:

```python
source_items = os.listdir(source_dir_drive)
for item in source_items:
    # copytree / copy2 each
```

If your Drive directory already contains `_Phase3/fonts/`, this loop will
pick it up automatically — *as long as* the directory exists on Drive.

**Verify it's there**: in cell 0, after the source listing prints, you
should see `fonts` among the lines starting with ` - `:
```
 - phase3
 - output
 - samples
 - fonts          ← required
 - render_plan.py
 - audit_plan.py
 - phase3_run.py
```

If you don't, run this once locally to upload it:

```bash
# From your local repo root
gcloud auth login   # or use the rclone / Drive web UI
# Or simply: drag-and-drop _Phase3/fonts/ into your Drive _Phase3/ folder
```

With the patched `typography.py`, **even if cell 0 doesn't copy
`fonts/`**, discovery will probe `/content/drive/MyDrive/_Phase3/fonts`
directly on the live Drive mount as a fallback (see Strategy 1 in
`_discover_amiri_fonts()`).  So the worst-case behaviour is one extra
Drive read per cold start, not a 6 MB upstream download.
