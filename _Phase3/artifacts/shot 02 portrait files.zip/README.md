# Shot 2 — using your own images

Two files matter:

1. **`shot_02_portrait/candidates.json`** — the *display* copy.  Lists every
   image you (or the prebuild pass) consider acceptable for this shot,
   with metadata.  The renderer does *not* read this file directly, so
   editing it doesn't change what gets rendered.  But it documents your
   choices and is what you'd hand to a reviewer.
2. **`decisions.json`** — at the review root (one level up from
   `shot_02_portrait/`).  This is the file the renderer actually
   consults.  The `chosen_file` field for each shot is the path the
   renderer uses.

## Drop-in `candidates.json` for shot 2

Save `candidates.json` (in this directory) as
`_Phase3/review/shot_02_portrait/candidates.json`.

The four `user_upload` entries are scored 9/9 — that's not vision-rubric
output, it's a manual "I, the user, certify this image is authoritative
for the subject".  Pexels candidates remain in the list as the
alternatives the prebuild pass found, for reference.

## Matching `decisions.json` entry

The snippet `decisions_shot02_snippet.json` shows just shot 2.  In your
real dossier, this lives inside the larger `decisions.json` at the
review root.  Three field equalities are what actually drive the render:

* `chosen` — human-readable, helps you diff the JSON.
* `chosen_url` — `file://` URI to the chosen file.
* `chosen_file` — **this is the only one the renderer reads.**  Path
  relative to the review root.  Set it to
  `shot_02_portrait/my_jafar_3a.jpg` and the renderer burns
  `my_jafar_3a.jpg` into shot 2.

## Quick way to switch to a different one of your four

Just change the three `chosen*` fields in `decisions.json`:

```json
"chosen_file": "shot_02_portrait/my_jafar_1.jpg"   ← swap "3a" for "1", "2", or "3"
```

`candidates.json` doesn't need a re-edit.

## To make every `portrait` shot use the same photo (recommended)

Instead of editing each shot, set the global pin once:

1. Copy your preferred file to `_Phase3/review/overrides/character.jpg`
2. In `decisions.json`, set:
   ```json
   "pinned_portrait": "overrides/character.jpg"
   ```

All five portrait shots in the al-Askari plan now use that single
photograph.  Per-shot `chosen_file` overrides the pin if you want one
portrait shot to be different.
